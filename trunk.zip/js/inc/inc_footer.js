var footer = '';

footer +=	'<div id="footer" class="sbox">Copyright 2013. SHH All Right Reserved.</div>'

document.write(footer);