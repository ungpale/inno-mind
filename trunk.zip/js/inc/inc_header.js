var header = '';

header +=	'<div id="header">'
header +=		'<h1><img src="images/logo_innomind.png" width="150" alt="이노마인드 마크업 가이드" /></h1>'
header +=		'<ul>'
header +=			'<li><a href="resume_a.html" class="on">HTML&CSS</a></li>'
header +=			'<li><a href="library_new.html">라이브러리</a></li>'
header +=			'<li><a href="pagelist.html">페이지리스트</a></li>'
header +=		'</ul>'
header +=	'</div>'

document.write(header);